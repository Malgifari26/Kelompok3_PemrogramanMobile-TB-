import 'package:flutter/material.dart';
import 'package:reqres_app/models/user.dart';
import 'package:reqres_app/services/api_service.dart';

class UserProvider with ChangeNotifier {
  final ApiService apiService;

  UserProvider({required this.apiService});

  List<User> _users = [];
  User? _selectedUser;
  bool _isLoading = false;

  List<User> get users => _users;
  User? get selectedUser => _selectedUser;
  bool get isLoading => _isLoading;

  Future<void> fetchUsers() async {
    _isLoading = true;
    notifyListeners();

    _users = await apiService.fetchUsers();

    _isLoading = false;
    notifyListeners();
  }

  Future<void> fetchUserById(int id) async {
    _isLoading = true;
    notifyListeners();

    _selectedUser = await apiService.fetchUserById(id);

    _isLoading = false;
    notifyListeners();
  }

  Future<void> createUser(User user) async {
    _isLoading = true;
    notifyListeners();

    await apiService.createUser(user);
    await fetchUsers();

    _isLoading = false;
    notifyListeners();
  }
}
