import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reqres_app/models/user.dart';
import 'package:reqres_app/providers/user_provider.dart';

class UserFormScreen extends StatefulWidget {
  static const routeName = '/user-form';

  @override
  _UserFormScreenState createState() => _UserFormScreenState();
}

class _UserFormScreenState extends State<UserFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, String> _formData = {
    'first_name': '',
    'last_name': '',
    'email': '',
    'avatar': ''
  };

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final newUser = User(
        id: 0,
        firstName: _formData['first_name']!,
        lastName: _formData['last_name']!,
        email: _formData['email']!,
        avatar: _formData['avatar']!,
      );

      Provider.of<UserProvider>(context, listen: false)
          .createUser(newUser)
          .then((_) {
        Navigator.of(context).pop();
      }).catchError((error) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('An error occurred!'),
            content: Text('Failed to create user.'),
            actions: <Widget>[
              TextButton(
                child: Text('Okay'),
                onPressed: () {
                  Navigator.of(ctx).pop();
                },
              )
            ],
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Pengguna'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                decoration: InputDecoration(labelText: 'First Name'),
                textInputAction: TextInputAction.next,
                onSaved: (value) {
                  _formData['first_name'] = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a first name';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Last Name'),
                textInputAction: TextInputAction.next,
                onSaved: (value) {
                  _formData['last_name'] = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a last name';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Email'),
                keyboardType: TextInputType.emailAddress,
                textInputAction: TextInputAction.next,
                onSaved: (value) {
                  _formData['email'] = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty || !value.contains('@')) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Avatar URL'),
                keyboardType: TextInputType.url,
                textInputAction: TextInputAction.done,
                onSaved: (value) {
                  _formData['avatar'] = value!;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an avatar URL';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                child: Text('Add User'),
                onPressed: _submitForm,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
