import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reqres_app/providers/user_provider.dart';

class UserDetailScreen extends StatelessWidget {
  static const routeName = '/user-detail';

  @override
  Widget build(BuildContext context) {
    final userId = ModalRoute.of(context)!.settings.arguments as int;

    return Scaffold(
      appBar: AppBar(
        title: Text('Pengguna'),
      ),
      body: FutureBuilder(
        future: Provider.of<UserProvider>(context, listen: false)
            .fetchUserById(userId),
        builder: (ctx, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else {
            if (snapshot.error != null) {
              return Center(child: Text('An error occurred!'));
            } else {
              return Consumer<UserProvider>(
                builder: (ctx, userProvider, _) {
                  final user = userProvider.selectedUser;
                  if (user == null) {
                    return Center(child: Text('User not found'));
                  } else {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            radius: 50,
                            backgroundImage: NetworkImage(user.avatar),
                          ),
                          SizedBox(height: 20),
                          Text(user.firstName + ' ' + user.lastName,
                              style: TextStyle(fontSize: 24)),
                          SizedBox(height: 10),
                          Text(user.email, style: TextStyle(fontSize: 16)),
                        ],
                      ),
                    );
                  }
                },
              );
            }
          }
        },
      ),
    );
  }
}
