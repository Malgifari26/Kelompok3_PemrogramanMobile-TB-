import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reqres_app/providers/user_provider.dart';
import 'package:reqres_app/screens/user_detail_screen.dart';
import 'package:reqres_app/screens/user_form_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Pengguna'), // Judul aplikasi
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.of(context).pushNamed(UserFormScreen.routeName);
            },
          ),
        ],
      ),
      body: FutureBuilder(
        future: Provider.of<UserProvider>(context, listen: false).fetchUsers(),
        builder: (ctx, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else {
            if (snapshot.error != null) {
              return Center(child: Text('An error occurred!'));
            } else {
              return Consumer<UserProvider>(
                builder: (ctx, userProvider, _) => ListView.builder(
                  itemCount: userProvider.users.length,
                  itemBuilder: (ctx, index) => ListTile(
                    leading: CircleAvatar(
                      backgroundImage:
                          NetworkImage(userProvider.users[index].avatar),
                    ),
                    title: Text(userProvider.users[index].firstName +
                        ' ' +
                        userProvider.users[index].lastName),
                    subtitle: Text(userProvider.users[index].email),
                    onTap: () {
                      Navigator.of(context).pushNamed(
                        UserDetailScreen.routeName,
                        arguments: userProvider.users[index].id,
                      );
                    },
                  ),
                ),
              );
            }
          }
        },
      ),
    );
  }
}
