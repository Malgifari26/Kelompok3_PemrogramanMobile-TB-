import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reqres_app/providers/user_provider.dart';
import 'package:reqres_app/services/api_service.dart';
import 'package:reqres_app/screens/home_screen.dart';
import 'package:reqres_app/screens/user_detail_screen.dart';
import 'package:reqres_app/screens/user_form_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UserProvider(apiService: ApiService()),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: '/',
        routes: {
          '/': (ctx) => HomeScreen(),
          UserDetailScreen.routeName: (ctx) => UserDetailScreen(),
          UserFormScreen.routeName: (ctx) => UserFormScreen(),
        },
      ),
    );
  }
}
